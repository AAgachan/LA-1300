﻿using System;
using System.Collections.Generic;

namespace LA_1300
    {
        internal class NumberGenerator
        {
            private Random random = new Random();

            public int Generate(int min, int max)
            {
                return random.Next(min, max + 1);
            }
        }

        internal class ScoreTracker //chat gpt
        {
            private const int MaxHighScores = 5;
            private List<int> highScores = new List<int>();

            public void AddScore(int score)
            {
                highScores.Add(score);
                highScores.Sort();

                if (highScores.Count > MaxHighScores)
                {
                    highScores.RemoveAt(highScores.Count - 1);
                }
            }

            public void Display()
            {
                Console.WriteLine("High Scores:");
                foreach (int score in highScores)
                {
                    Console.WriteLine(score);
                }
            }
        }

        public class Game
        {
            private const int MinNumber = 1;
            private int maxNumber;
            private int secretNumber;
            private int guess;
            private int guessCount;
            private NumberGenerator numberGenerator = new NumberGenerator();
            private ScoreTracker scoreTracker = new ScoreTracker();

            public void Play()
            {
                while (true)
                {
                    guessCount = 0;

                    Console.WriteLine("Select game mode:\n1. Single Player\n2. Two Player");
                    int gameMode;
                    while (!int.TryParse(Console.ReadLine(), out gameMode) || (gameMode != 1 && gameMode != 2))
                    {
                        Console.WriteLine("Please enter 1 for Single Player or 2 for Two Player.");
                    }
                    Console.Clear();

                    switch (gameMode)
                    {
                        case 1:
                            SinglePlayer();
                            break;
                        case 2:
                            TwoPlayer();
                            break;
                    }

                    DisplayHighScores();
                }
            }

            private void SinglePlayer()
            {
                maxNumber = GetNumberFromUser("Choose the maximum number for guessing: ");
                secretNumber = numberGenerator.Generate(MinNumber, maxNumber);
                GuessAndCheck();
            }

            private void TwoPlayer()
            {
                maxNumber = GetNumberFromUser("Choose the maximum number for guessing: ");
                secretNumber = GetNumberFromUser("Choose the number for the other player to guess: ");
                GuessAndCheck();
            }

            private void GuessAndCheck()//chatgpt
            {
                Console.WriteLine($"Guess the number between {MinNumber} and {maxNumber}:");
                while (!int.TryParse(Console.ReadLine(), out guess) || guess < MinNumber || guess > maxNumber)
                {
                    Console.WriteLine($"Please enter a number between {MinNumber} and {maxNumber}.");
                }
                guessCount++;

                while (secretNumber != guess)
                {
                    guessCount++;
                    Console.WriteLine(guess < secretNumber ? "Your guess is lower than the actual number. Try Again!" : "Your guess is higher than the actual number. Try Again!");

                    while (!int.TryParse(Console.ReadLine(), out guess) || guess < MinNumber || guess > maxNumber)
                    {
                        Console.WriteLine($"Please enter a number between {MinNumber} and {maxNumber}.");
                    }
                }

                Console.WriteLine($"Congratulations! You have guessed the correct number in {guessCount} guesses.");
                scoreTracker.AddScore(guessCount);
            }

            private int GetNumberFromUser(string message)
            {
                Console.WriteLine(message);
                int number;
                while (!int.TryParse(Console.ReadLine(), out number) || number <= 0)
                {
                    Console.WriteLine("Please enter a number.");
                }
                return number;
            }

            private void DisplayHighScores()
            {
                scoreTracker.Display();
            }
        }

        internal class Program
        {
            private static void Main()
            {
                Game game = new Game();
                game.Play();
            }
        }
}

